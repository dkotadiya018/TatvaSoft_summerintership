﻿using Microsoft.EntityFrameworkCore;
using Mission.Entities.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace Mission.Entities
{
    public class MissionDbContext(DbContextOptions<MissionDbContext> options) : DbContext(options)
    {
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(new User()
            {
                Id = 1,
                FirstName = "Dhruv",
                LastName = "Kotadiya",
                EmailAddress = "dk@tatvasoft.com",
                Password = "123456",
                PhoneNumber = "9876543210",
                UserType = "admin",
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
